"""
xai_engine.py — Pure-Python Explainable AI for MedAI
No external APIs. Uses diseases_data.json + patient inputs to generate
structured explanations: why this disease, why it occurred, how to prevent it.
"""

import os
import json

_DATA_PATH = os.path.join(os.path.dirname(__file__), "diseases_data.json")
with open(_DATA_PATH, encoding="utf-8") as _f:
    _DISEASES_LIST = json.load(_f)

# Quick lookup by name
DISEASE_MAP = {d["name"]: d for d in _DISEASES_LIST}

# ── Static knowledge: causes and prevention per disease ───────────────────────
# Built from established medical knowledge, not from any API.

_DISEASE_KNOWLEDGE = {
    "Influenza": {
        "causes": [
            "Caused by influenza A or B viruses transmitted via respiratory droplets and airborne particles.",
            "Spreads rapidly in crowded environments and cold weather when people spend more time indoors.",
            "The virus mutates frequently, making previous immunity less effective each season.",
        ],
        "prevention": [
            "Get an annual flu vaccine — it's the single most effective preventive measure.",
            "Wash hands frequently with soap for at least 20 seconds, especially after coughing or sneezing.",
            "Avoid close contact with sick individuals and stay home if you feel unwell.",
            "Keep your immune system strong through adequate sleep, balanced nutrition, and regular exercise.",
        ],
        "risk_factors": {
            "age": ("The elderly (65+) and young children (under 5) face higher complication risks.", 65, 5),
            "Asthma": "Asthma increases risk of severe flu complications and pneumonia.",
            "COPD": "COPD patients are at high risk for flu-related respiratory failure.",
            "Diabetes": "Diabetes impairs immune response, making flu harder to fight.",
            "Heart Disease": "Heart disease raises risk of flu-triggered cardiac events.",
            "Immunocompromised": "A weakened immune system cannot mount an adequate defense against the virus.",
        },
    },
    "Common Cold": {
        "causes": [
            "Caused by over 200 different viruses, most commonly rhinoviruses, spread by direct contact and airborne droplets.",
            "Colds are more prevalent in winter when people congregate indoors with poor ventilation.",
            "Touching contaminated surfaces and then touching the face is a major transmission route.",
        ],
        "prevention": [
            "Wash hands regularly, especially before eating or touching your face.",
            "Avoid touching your eyes, nose, and mouth with unwashed hands.",
            "Maintain good ventilation indoors and avoid crowded enclosed spaces during cold season.",
            "Stay well-rested and manage stress, as sleep deprivation significantly weakens immunity.",
        ],
        "risk_factors": {},
    },
    "Pneumonia": {
        "causes": [
            "Caused by bacteria (most commonly Streptococcus pneumoniae), viruses, or fungi infecting the lung tissue.",
            "Often develops as a complication of the flu or other respiratory infections when immunity is reduced.",
            "Risk is elevated in those with underlying lung disease, weakened immunity, or poor nutrition.",
        ],
        "prevention": [
            "Get vaccinated — pneumococcal and flu vaccines significantly reduce pneumonia risk.",
            "Avoid smoking, which damages lung defense mechanisms and increases susceptibility.",
            "Treat respiratory infections promptly before they progress to the lungs.",
            "For high-risk individuals, ensure adequate nutrition and manage underlying conditions closely.",
        ],
        "risk_factors": {
            "Diabetes": "High blood sugar impairs white blood cell function, slowing infection clearance.",
            "COPD": "Damaged airways in COPD create a pathway for pathogens to reach the lungs.",
            "Heart Disease": "Reduced cardiac output impairs lung blood flow, increasing infection risk.",
            "Immunocompromised": "Without adequate immune defenses, even mild bacteria can cause severe pneumonia.",
            "Asthma": "Inflamed airways in asthma are more susceptible to secondary bacterial infection.",
        },
    },
    "Parainfluenza": {
        "causes": [
            "Caused by human parainfluenza viruses (HPIVs), common in autumn and spring seasons.",
            "Spread through respiratory droplets and direct contact with contaminated surfaces.",
            "Most dangerous in children under 5 and immunocompromised adults.",
        ],
        "prevention": [
            "Practice frequent handwashing and avoid sharing utensils or cups.",
            "Keep children with symptoms home from school to prevent spread.",
            "Disinfect frequently touched surfaces regularly.",
            "Immunocompromised individuals should avoid contact with anyone showing cold-like symptoms.",
        ],
        "risk_factors": {
            "Asthma": "Can trigger severe asthma attacks in affected patients.",
            "COPD": "Can cause serious lower respiratory tract disease in COPD patients.",
            "Immunocompromised": "May cause life-threatening pneumonia in immunocompromised individuals.",
            "Heart Disease": "Respiratory strain can place added burden on a weakened heart.",
        },
    },
    "Bronchitis": {
        "causes": [
            "Acute bronchitis is usually caused by viruses (same as cold/flu) infecting the bronchial tubes.",
            "Chronic bronchitis is primarily caused by long-term exposure to irritants, especially cigarette smoke.",
            "Air pollution, chemical fumes, and dust are secondary contributors to bronchial inflammation.",
        ],
        "prevention": [
            "Do not smoke and avoid secondhand smoke — it is the leading cause of chronic bronchitis.",
            "Wear a mask in dusty or chemically polluted environments.",
            "Get vaccinated against flu and pneumonia to reduce acute bronchitis risk.",
            "Treat respiratory infections early before they descend into the bronchial tubes.",
        ],
        "risk_factors": {
            "Asthma": "Pre-existing airway inflammation in asthma heightens bronchitis severity.",
            "COPD": "Patients with COPD are at high risk for recurring acute bronchitis episodes.",
            "Smoking": "Smoking is the primary cause of chronic bronchitis and significantly worsens acute episodes.",
        },
    },
    "Asthma": {
        "causes": [
            "Asthma involves chronic airway inflammation and hypersensitivity triggered by allergens, irritants, or exercise.",
            "Genetic predisposition combined with early-life environmental exposures (dust, smoke, mold) plays a central role.",
            "Obesity, respiratory infections in childhood, and allergic conditions increase asthma risk.",
        ],
        "prevention": [
            "Identify and avoid personal triggers — common ones include dust mites, pet dander, and cold air.",
            "Use prescribed controller inhalers consistently, not just during attacks.",
            "Maintain a healthy weight; obesity significantly worsens asthma severity.",
            "Keep living spaces clean, well-ventilated, and free of mold and smoke.",
        ],
        "risk_factors": {
            "Allergic Rhinitis": "Allergic rhinitis and asthma share the same inflammatory pathway and frequently co-occur.",
            "Eczema": "Atopic conditions like eczema indicate systemic immune hypersensitivity that also affects the airways.",
            "Obesity": "Excess weight restricts lung expansion and promotes systemic inflammation that worsens asthma.",
        },
    },
    "Allergic Rhinitis": {
        "causes": [
            "Caused by an IgE-mediated immune overreaction to airborne allergens such as pollen, dust mites, and mold.",
            "Genetic predisposition to atopy (allergic sensitivity) is the primary risk factor.",
            "Seasonal triggers (tree pollen in spring, grass in summer) cause predictable flares.",
        ],
        "prevention": [
            "Use antihistamines and nasal corticosteroid sprays as preventive therapy before allergen season.",
            "Keep windows closed during high-pollen periods and use air purifiers with HEPA filters indoors.",
            "Shower and change clothes after spending time outdoors during pollen season.",
            "Consider allergen immunotherapy (allergy shots) for long-term desensitization.",
        ],
        "risk_factors": {
            "Asthma": "Asthma and allergic rhinitis share immune pathways; one worsens the other.",
            "Eczema": "Eczema is a sign of atopic constitution, which predisposes to respiratory allergies.",
        },
    },
    "Sinusitis": {
        "causes": [
            "Sinusitis occurs when the sinus cavities become inflamed, usually following a cold or allergic reaction.",
            "Bacteria (Streptococcus, Haemophilus) can colonize congested sinuses, turning viral to bacterial infection.",
            "Structural issues such as nasal polyps or a deviated septum promote chronic sinusitis.",
        ],
        "prevention": [
            "Treat nasal congestion and allergies promptly to prevent sinus blockage.",
            "Use saline nasal rinses to flush irritants and keep sinuses moist.",
            "Stay hydrated to keep mucus thin and drainage flowing.",
            "Avoid cigarette smoke and air pollutants that inflame the nasal lining.",
        ],
        "risk_factors": {
            "Allergic Rhinitis": "Chronic nasal inflammation from allergies blocks sinus drainage, fostering sinusitis.",
            "Asthma": "Shared airway inflammation between asthma and sinusitis is common.",
        },
    },
    "Tuberculosis": {
        "causes": [
            "Caused by Mycobacterium tuberculosis, spread through airborne droplets from infected individuals.",
            "Prolonged close contact with an active TB case in poorly ventilated spaces is the primary risk.",
            "Weakened immune systems allow latent TB to become active disease.",
        ],
        "prevention": [
            "BCG vaccination provides protection especially in high-prevalence regions.",
            "Ensure good ventilation in living and working spaces to dilute airborne particles.",
            "If exposed, get tested promptly and complete any prescribed preventive antibiotic course.",
            "Maintain nutritional status and manage HIV or diabetes, which dramatically increase TB activation risk.",
        ],
        "risk_factors": {
            "Diabetes": "Poorly controlled diabetes triples the risk of active TB by impairing immune cell function.",
            "HIV/AIDS": "HIV destroys the CD4 cells that contain TB, making coinfection extremely dangerous.",
            "Immunocompromised": "Any immune suppression allows dormant TB bacteria to proliferate unchecked.",
            "Malnutrition": "Malnutrition severely impairs T-cell immunity, the primary defense against TB.",
        },
    },
    "Dengue Fever": {
        "causes": [
            "Caused by dengue virus (DENV 1–4) transmitted exclusively by Aedes aegypti mosquito bites.",
            "Prevalent in tropical and subtropical regions; risk peaks during monsoon season when mosquito populations surge.",
            "There is no direct person-to-person transmission — the mosquito is the only vector.",
        ],
        "prevention": [
            "Eliminate standing water around your home — flowerpots, coolers, and water containers are mosquito breeding grounds.",
            "Use mosquito repellents containing DEET or picaridin on exposed skin, especially at dawn and dusk.",
            "Sleep under insecticide-treated mosquito nets and use window screens.",
            "Wear full-sleeved clothing when outdoors in high-risk areas.",
        ],
        "risk_factors": {
            "Diabetes": "Diabetes patients face higher risk of dengue hemorrhagic fever and severe complications.",
            "Heart Disease": "Cardiac complications are more likely in dengue patients with pre-existing heart disease.",
        },
    },
    "Malaria": {
        "causes": [
            "Caused by Plasmodium parasites (P. falciparum most dangerous) transmitted by Anopheles mosquito bites.",
            "Endemic in sub-Saharan Africa, South Asia, and parts of Latin America; risk is highest near stagnant water.",
            "The parasite invades red blood cells, causing cycles of fever and anemia.",
        ],
        "prevention": [
            "Take prescribed antimalarial prophylaxis medication when traveling to endemic areas.",
            "Sleep under insecticide-treated bed nets and apply mosquito repellent consistently.",
            "Drain or treat stagnant water sources near your home to eliminate breeding grounds.",
            "Wear long-sleeved clothing and use permethrin-treated fabrics in high-risk regions.",
        ],
        "risk_factors": {
            "Anemia": "Malaria destroys red blood cells; pre-existing anemia makes this depletion life-threatening.",
            "Sickle Cell": "Sickle cell trait offers partial protection, but full sickle cell disease worsens malaria outcomes.",
            "Immunocompromised": "Weakened immunity prevents effective clearance of the parasite from the bloodstream.",
        },
    },
    "Typhoid Fever": {
        "causes": [
            "Caused by Salmonella typhi bacteria, transmitted through contaminated food and water.",
            "Poor sanitation and inadequate sewage disposal are the primary environmental drivers.",
            "Fecal-oral transmission: the bacteria shed in the stool of infected people contaminates water supplies.",
        ],
        "prevention": [
            "Drink only boiled or bottled water and avoid raw foods washed with tap water in endemic areas.",
            "Get typhoid vaccination before traveling to high-risk regions.",
            "Practice strict hand hygiene, especially after using the toilet and before eating.",
            "Ensure food is thoroughly cooked and served hot; avoid street food with unknown hygiene standards.",
        ],
        "risk_factors": {
            "Immunocompromised": "Immune suppression prevents the body from containing the bacterial spread.",
            "Malnutrition": "Malnourished individuals cannot mount the antibody response needed to fight typhoid.",
        },
    },
    "Gastroenteritis": {
        "causes": [
            "Caused by viral (norovirus, rotavirus), bacterial (Salmonella, E. coli), or parasitic pathogens ingested via contaminated food or water.",
            "Spreads easily in households and institutions; norovirus can survive on surfaces for days.",
            "Poor food handling, undercooking, and cross-contamination in kitchens are common causes.",
        ],
        "prevention": [
            "Wash hands thoroughly before preparing food and after using the bathroom.",
            "Cook foods to safe internal temperatures and refrigerate perishables promptly.",
            "Avoid consuming raw or undercooked shellfish, eggs, and meat.",
            "Stay home when sick to avoid spreading infection to others, especially in food-handling roles.",
        ],
        "risk_factors": {
            "Immunocompromised": "Pathogens cause much more severe and prolonged illness without a functional immune system.",
            "Inflammatory Bowel Disease": "Existing gut inflammation makes the intestinal lining more vulnerable to infectious agents.",
        },
    },
    "Ulcerative Colitis": {
        "causes": [
            "An autoimmune inflammatory bowel disease where the immune system mistakenly attacks the colon lining.",
            "Exact cause is unknown, but involves a combination of genetic susceptibility and environmental triggers.",
            "Dysbiosis (imbalance in gut microbiome) is thought to play a key role in triggering inflammation.",
        ],
        "prevention": [
            "Maintain a food diary to identify and avoid personal dietary triggers (common ones: dairy, high-fiber, spicy foods).",
            "Take prescribed maintenance medications consistently even during remission to prevent flares.",
            "Manage stress through mindfulness, exercise, or therapy — stress is a known flare trigger.",
            "Schedule regular colonoscopies as ulcerative colitis increases colorectal cancer risk over time.",
        ],
        "risk_factors": {
            "Crohn's Disease": "Both conditions share autoimmune inflammatory pathways and frequently coexist or overlap.",
            "Autoimmune Disorder": "Having one autoimmune condition increases susceptibility to others including UC.",
        },
    },
    "Crohn's Disease": {
        "causes": [
            "An autoimmune condition causing patchy transmural inflammation anywhere in the GI tract.",
            "Involves genetic mutations (NOD2 gene), immune dysregulation, and altered gut microbiome composition.",
            "Smoking doubles the risk of Crohn's disease and worsens disease course.",
        ],
        "prevention": [
            "Do not smoke — it is one of the few modifiable risk factors proven to worsen Crohn's.",
            "Follow a low-residue diet during flares and identify personal food triggers.",
            "Adhere strictly to prescribed immunomodulator or biologic therapy to maintain remission.",
            "Manage psychological stress, which is closely linked to flare frequency in Crohn's.",
        ],
        "risk_factors": {
            "Ulcerative Colitis": "A personal or family history of UC indicates immune predisposition to IBD.",
            "Autoimmune Disorder": "Systemic immune dysregulation increases risk of developing Crohn's disease.",
        },
    },
    "Pancreatitis": {
        "causes": [
            "Acute pancreatitis is most commonly caused by gallstones blocking the pancreatic duct and excessive alcohol use.",
            "Elevated triglycerides (from high cholesterol) and certain medications are additional triggers.",
            "Chronic pancreatitis develops from repeated acute episodes, causing permanent gland damage.",
        ],
        "prevention": [
            "Avoid excessive alcohol consumption — it is a leading preventable cause of pancreatitis.",
            "Maintain healthy cholesterol and triglyceride levels through diet and medication if needed.",
            "Address gallstones early through dietary changes or surgery before they trigger an acute attack.",
            "Follow a low-fat diet to reduce pancreatic workload and triglyceride levels.",
        ],
        "risk_factors": {
            "Diabetes": "Pancreatitis damages insulin-producing cells, worsening or triggering diabetes.",
            "Gallstones": "Gallstones are the single most common cause of acute pancreatitis.",
            "Alcoholism": "Alcohol is directly toxic to pancreatic cells and causes both acute and chronic pancreatitis.",
        },
    },
    "Liver Disease": {
        "causes": [
            "Caused by viral hepatitis (B, C), excessive alcohol consumption, fatty liver disease (NAFLD), or autoimmune conditions.",
            "The liver sustains cumulative damage from toxins, fat deposits, and inflammation over years.",
            "Non-alcoholic fatty liver disease is now the leading cause, driven by obesity and metabolic syndrome.",
        ],
        "prevention": [
            "Limit alcohol intake to within recommended guidelines (or abstain if any liver disease is present).",
            "Get vaccinated against hepatitis A and B; avoid sharing needles or personal items.",
            "Maintain a healthy weight and manage diabetes to prevent fatty liver progression.",
            "Review medications with your doctor, as many common drugs are hepatotoxic at high doses.",
        ],
        "risk_factors": {
            "Diabetes": "Insulin resistance promotes hepatic fat accumulation, accelerating NAFLD progression.",
            "Obesity": "Obesity is the primary driver of non-alcoholic fatty liver disease.",
            "Alcoholism": "Alcohol is directly hepatotoxic and the leading cause of cirrhosis.",
            "Hepatitis B": "Chronic HBV infection causes progressive liver fibrosis and raises hepatocellular carcinoma risk.",
            "Hepatitis C": "Chronic HCV infection leads to cirrhosis in ~20% of patients over 20 years.",
        },
    },
    "Kidney Disease": {
        "causes": [
            "Chronic kidney disease (CKD) is most commonly caused by diabetes and hypertension damaging the glomeruli.",
            "Recurrent urinary tract infections, kidney stones, and certain medications (NSAIDs) can also cause progressive damage.",
            "The kidneys lose filtering function gradually; early stages are often asymptomatic.",
        ],
        "prevention": [
            "Control blood sugar tightly if diabetic — it is the leading cause of kidney failure worldwide.",
            "Keep blood pressure below 130/80 mmHg; hypertension directly damages kidney blood vessels.",
            "Stay well-hydrated and avoid prolonged use of NSAIDs (ibuprofen, naproxen) which reduce kidney blood flow.",
            "Get regular kidney function tests (eGFR, creatinine) if you have diabetes or hypertension.",
        ],
        "risk_factors": {
            "Diabetes": "Diabetic nephropathy accounts for ~40% of all end-stage kidney disease cases.",
            "Hypertension": "Elevated blood pressure physically damages the delicate glomerular capillaries.",
            "Heart Disease": "Reduced cardiac output decreases renal perfusion, accelerating kidney damage.",
        },
    },
    "Diabetes": {
        "causes": [
            "Type 2 diabetes (most common) results from insulin resistance compounded by inadequate pancreatic compensation.",
            "Driven by genetic predisposition activated by lifestyle factors: excess body weight, physical inactivity, and poor diet.",
            "Type 1 diabetes is autoimmune destruction of pancreatic beta cells, unrelated to lifestyle.",
        ],
        "prevention": [
            "Maintain a healthy weight — losing even 5–7% of body weight dramatically reduces type 2 diabetes risk.",
            "Exercise at least 150 minutes per week of moderate aerobic activity to improve insulin sensitivity.",
            "Adopt a diet low in refined carbohydrates and added sugars; emphasize vegetables, legumes, and whole grains.",
            "Monitor fasting blood glucose regularly if you have risk factors; prediabetes is reversible with early action.",
        ],
        "risk_factors": {
            "Obesity": "Visceral fat is the primary driver of insulin resistance and type 2 diabetes.",
            "Hypertension": "Hypertension and diabetes share metabolic risk factors and frequently co-occur.",
            "Heart Disease": "Insulin resistance contributes to atherosclerosis; diabetes and heart disease are tightly linked.",
            "Kidney Disease": "Kidney disease impairs glucose metabolism and is also a major diabetes complication.",
        },
    },
    "Hypertension": {
        "causes": [
            "Primary hypertension has no single cause but results from an interplay of genetics, age, diet, and lifestyle.",
            "High sodium intake causes fluid retention; obesity increases cardiac output and vascular resistance.",
            "Secondary hypertension can result from kidney disease, thyroid disorders, or sleep apnea.",
        ],
        "prevention": [
            "Reduce sodium intake to under 2,300 mg/day (ideally 1,500 mg); avoid processed and packaged foods.",
            "Maintain a healthy weight and exercise regularly — even 30 minutes of walking daily lowers BP.",
            "Limit alcohol, quit smoking, and manage stress through relaxation techniques like yoga or meditation.",
            "Monitor blood pressure at home regularly and take medications as prescribed without interruption.",
        ],
        "risk_factors": {
            "Diabetes": "Hyperglycemia damages arterial walls and promotes hypertension through multiple mechanisms.",
            "Obesity": "Excess weight forces the heart to work harder, raising baseline blood pressure.",
            "Kidney Disease": "The kidneys regulate blood pressure; kidney disease disrupts this control system.",
            "Heart Disease": "Heart disease and hypertension are bidirectionally linked — each worsens the other.",
        },
    },
    "Stroke": {
        "causes": [
            "Ischemic stroke (85% of cases) occurs when a clot blocks blood flow to a brain region, causing tissue death.",
            "Hemorrhagic stroke results from a ruptured blood vessel, often due to chronically high blood pressure.",
            "Atrial fibrillation causes irregular clot formation in the heart that can travel to the brain.",
        ],
        "prevention": [
            "Control blood pressure rigorously — it is the single most important modifiable stroke risk factor.",
            "Take prescribed anticoagulants if you have atrial fibrillation to prevent clot formation.",
            "Quit smoking immediately; smoking doubles stroke risk by promoting clot formation and arterial damage.",
            "Manage cholesterol, blood sugar, and maintain a healthy weight to reduce atherosclerosis progression.",
        ],
        "risk_factors": {
            "Hypertension": "Hypertension is the leading cause of both ischemic and hemorrhagic stroke.",
            "Diabetes": "Diabetes accelerates atherosclerosis and significantly raises ischemic stroke risk.",
            "Heart Disease": "Cardiac conditions such as heart failure produce emboli that travel to the cerebral circulation.",
            "Atrial Fibrillation": "AF causes pooling of blood in the heart, forming clots that cause embolic strokes.",
        },
    },
    "Migraine": {
        "causes": [
            "Migraines involve neurological sensitization and cortical spreading depression, a wave of electrical activity across the brain.",
            "Triggered by hormonal changes, sleep disruption, stress, certain foods (tyramine, caffeine), and environmental stimuli.",
            "Genetics play a strong role; migraines often run in families.",
        ],
        "prevention": [
            "Keep a headache diary to identify and systematically eliminate personal triggers.",
            "Maintain consistent sleep and wake times — irregular sleep is one of the most potent migraine triggers.",
            "Consider preventive medications (beta-blockers, topiramate, CGRP antagonists) if attacks are frequent.",
            "Manage stress through regular exercise, mindfulness, and cognitive behavioral therapy.",
        ],
        "risk_factors": {
            "Hypertension": "Elevated blood pressure and vascular instability can precipitate migraine attacks.",
            "Anxiety": "Anxiety and migraine are bidirectionally linked through shared neurological pathways.",
            "Depression": "Depression and chronic pain share neurochemical pathways that amplify migraine frequency.",
        },
    },
    "Rheumatoid Arthritis": {
        "causes": [
            "An autoimmune disease where the immune system attacks synovial joints, causing chronic inflammation and cartilage destruction.",
            "Genetic factors (HLA-DR4) combined with environmental triggers (smoking, infection) initiate the autoimmune cascade.",
            "Women are affected 2–3 times more than men; onset peaks in middle age.",
        ],
        "prevention": [
            "Do not smoke — smoking is the strongest known environmental risk factor for RA and worsens disease activity.",
            "Maintain a healthy weight to reduce joint mechanical stress and systemic inflammation.",
            "Engage in regular low-impact exercise (swimming, cycling) to maintain joint mobility and muscle strength.",
            "Seek early diagnosis and treatment; early aggressive therapy prevents joint destruction and disability.",
        ],
        "risk_factors": {
            "Autoimmune Disorder": "Existing autoimmune conditions indicate systemic immune dysregulation predisposing to RA.",
            "Smoking": "Smoking induces citrullination of proteins that trigger anti-CCP antibody production in RA.",
            "Family History": "First-degree relatives of RA patients have a 3–5× higher risk of developing the disease.",
        },
    },
    "Osteoarthritis": {
        "causes": [
            "Osteoarthritis is caused by the gradual breakdown of articular cartilage due to mechanical wear, aging, and inflammation.",
            "Previous joint injuries, repetitive joint stress, and obesity accelerate cartilage degradation.",
            "Aging reduces the body's ability to repair cartilage, making OA nearly universal in those over 65.",
        ],
        "prevention": [
            "Maintain a healthy weight — every extra kilogram adds approximately 4 kg of force on each knee.",
            "Exercise regularly with low-impact activities to strengthen muscles that stabilize and protect joints.",
            "Avoid repetitive joint stress and use proper ergonomic technique when lifting or performing manual tasks.",
            "Treat joint injuries promptly and thoroughly; unhealed injuries predispose to early OA.",
        ],
        "risk_factors": {
            "Obesity": "Obesity is the most important modifiable risk factor for knee and hip osteoarthritis.",
            "Diabetes": "Hyperglycemia promotes advanced glycation end-products that stiffen and degrade cartilage.",
            "Previous Joint Injury": "Post-traumatic OA accounts for ~12% of all OA cases in weight-bearing joints.",
        },
    },
    "Osteoporosis": {
        "causes": [
            "Occurs when bone resorption outpaces bone formation, reducing bone mineral density and increasing fracture risk.",
            "Peak bone mass is achieved by age 30; factors in youth (nutrition, exercise) determine lifelong bone strength.",
            "Estrogen deficiency after menopause accelerates bone loss dramatically in women.",
        ],
        "prevention": [
            "Ensure adequate calcium (1000–1200 mg/day) and vitamin D (800–2000 IU/day) throughout life.",
            "Perform weight-bearing and resistance exercises (walking, weightlifting) to stimulate bone remodeling.",
            "Avoid smoking and limit alcohol; both reduce bone density through multiple mechanisms.",
            "Get bone density (DEXA) scans as recommended if you are postmenopausal or have risk factors.",
        ],
        "risk_factors": {
            "Menopause": "Estrogen loss after menopause is the leading cause of osteoporosis in women.",
            "Smoking": "Smoking reduces estrogen levels and impairs the osteoblast bone-building cells.",
            "Corticosteroid Use": "Long-term steroids inhibit bone formation and accelerate calcium loss from bones.",
            "Calcium Deficiency": "Inadequate calcium causes the body to leach calcium from bones to maintain blood levels.",
        },
    },
    "Eczema": {
        "causes": [
            "Eczema (atopic dermatitis) results from a defective skin barrier combined with immune hypersensitivity.",
            "Mutations in the filaggrin gene impair the skin's protective barrier, allowing allergens and irritants to penetrate.",
            "Triggered by soaps, detergents, stress, heat, and allergens like dust mites and pet dander.",
        ],
        "prevention": [
            "Moisturize skin immediately after bathing using fragrance-free, thick creams or ointments.",
            "Use mild, fragrance-free soaps and laundry detergents; avoid fabric softeners.",
            "Identify and avoid personal triggers; keep a skin diary tracking flares and exposures.",
            "Maintain cool, humid indoor environments to prevent skin drying and irritation.",
        ],
        "risk_factors": {
            "Allergic Rhinitis": "Co-occurring atopic conditions like allergic rhinitis indicate shared immune hypersensitivity.",
            "Asthma": "The atopic march — eczema in infancy often progresses to asthma and allergic rhinitis.",
            "Autoimmune Disorder": "Autoimmune predisposition contributes to the dysregulated immune response in eczema.",
        },
    },
    "Psoriasis": {
        "causes": [
            "An autoimmune condition where T-cells mistakenly attack skin cells, causing rapid skin cell turnover and plaque formation.",
            "Genetic susceptibility (HLA-Cw6 allele) combined with triggers: infections, stress, medications, and alcohol.",
            "Psoriasis is a systemic inflammatory disease with cardiovascular and metabolic comorbidities.",
        ],
        "prevention": [
            "Avoid known personal triggers: excessive alcohol, smoking, stress, and skin injury (Koebner phenomenon).",
            "Maintain a healthy weight — obesity worsens psoriasis severity and reduces treatment response.",
            "Take prescribed systemic or biologic therapies consistently to control immune dysregulation.",
            "Protect skin from trauma; even minor cuts and sunburn can trigger new psoriatic lesions.",
        ],
        "risk_factors": {
            "Autoimmune Disorder": "Psoriasis often co-occurs with other autoimmune conditions like psoriatic arthritis.",
            "Stress": "Psychological stress is a major and well-documented psoriasis flare trigger.",
            "Obesity": "Adipose tissue secretes pro-inflammatory cytokines that exacerbate psoriatic inflammation.",
        },
    },
    "Urinary Tract Infection": {
        "causes": [
            "Caused by bacteria (most commonly E. coli from the gut) ascending into the urethra and bladder.",
            "Women are far more susceptible due to a shorter urethra that is anatomically closer to the anus.",
            "Poor hygiene, dehydration, urinary retention, and catheter use are major contributing factors.",
        ],
        "prevention": [
            "Drink plenty of water (at least 2 liters/day) to flush bacteria from the urinary tract.",
            "Urinate after sexual intercourse to expel bacteria introduced during sex.",
            "Wipe front to back after using the toilet to prevent fecal bacteria from reaching the urethra.",
            "Avoid holding urine for prolonged periods; empty your bladder regularly and completely.",
        ],
        "risk_factors": {
            "Diabetes": "High blood sugar creates a favorable environment for bacterial growth in urine.",
            "Kidney Disease": "Impaired kidney function reduces the urinary tract's ability to clear pathogens.",
            "Immunocompromised": "Weakened immunity allows bacteria to establish infection more easily and resist treatment.",
        },
    },
}


def _get_symptom_contribution(symptom_key: str, probability: float, disease: dict) -> str:
    """Return how strongly a symptom contributed to the score."""
    sym_prob = disease["symptoms"].get(symptom_key, 0)
    name = symptom_key.replace("_", " ")
    if sym_prob >= 0.75:
        return f"{name} (very strong indicator — {int(sym_prob*100)}% likelihood in this disease)"
    elif sym_prob >= 0.5:
        return f"{name} (moderate indicator — {int(sym_prob*100)}% likelihood)"
    else:
        return f"{name} (supporting indicator — {int(sym_prob*100)}% likelihood)"


def explain(payload: dict) -> dict:
    """
    Pure-Python XAI. No external API.
    payload keys: disease_name, probability, matched_symptoms, age,
                  bp, cholesterol, preexisting, belief_trace
    Returns: { why_disease, why_occurred, how_to_prevent, key_drivers }
    """
    disease_name     = payload.get("disease_name", "Unknown")
    probability      = float(payload.get("probability", 0))
    matched_symptoms = payload.get("matched_symptoms", [])
    age              = payload.get("age")
    bp               = payload.get("bp", "Unknown")
    cholesterol      = payload.get("cholesterol", "Unknown")
    preexisting      = payload.get("preexisting", [])

    disease = DISEASE_MAP.get(disease_name, {})
    knowledge = _DISEASE_KNOWLEDGE.get(disease_name, {})
    key_symptoms = set(disease.get("key_symptoms", []))

    # ── 1. WHY THIS DISEASE ──────────────────────────────────────────────────
    matched_set = set(matched_symptoms)

    # Key symptoms the patient has
    matching_key = [s for s in matched_symptoms if s in key_symptoms]
    supporting   = [s for s in matched_symptoms if s not in key_symptoms]

    why_parts = []

    if matching_key:
        names = ", ".join(s.replace("_", " ") for s in matching_key[:4])
        sym_probs = [disease["symptoms"].get(s, 0) for s in matching_key]
        avg = int(sum(sym_probs) / len(sym_probs) * 100) if sym_probs else 0
        why_parts.append(
            f"Your reported symptoms — {names} — are among the most characteristic signs of "
            f"{disease_name}, with an average {avg}% symptom probability in this condition."
        )

    if supporting:
        names = ", ".join(s.replace("_", " ") for s in supporting[:3])
        why_parts.append(
            f"Additional symptoms ({names}) further support this match by reinforcing the overall symptom pattern."
        )

    # Age context
    age_mean = disease.get("age_mean")
    age_std  = disease.get("age_std", 20)
    if age is not None and age_mean is not None:
        try:
            age_val = float(age)
            if abs(age_val - age_mean) <= age_std:
                why_parts.append(
                    f"Your age ({int(age_val)}) falls within the typical risk window for {disease_name} "
                    f"(peak incidence around age {age_mean}), which increased the Bayesian score."
                )
        except (TypeError, ValueError):
            pass

    # BP context
    bp_mods = disease.get("bp_modifier", {})
    bp_val = bp_mods.get(bp, 1.0)
    if bp != "Unknown" and bp_val > 1.1:
        why_parts.append(
            f"Your {bp.lower()} blood pressure is associated with higher {disease_name} risk "
            f"(score multiplier: {bp_val:.1f}×)."
        )

    # Preexisting
    pre_mods = disease.get("preexisting_modifiers", {})
    active_pre = [p for p in preexisting if p in pre_mods]
    if active_pre:
        mods = [f"{p} ({pre_mods[p]:.1f}×)" for p in active_pre]
        why_parts.append(
            f"Pre-existing condition(s) — {', '.join(mods)} — significantly boosted the probability score."
        )

    if not why_parts:
        why_parts.append(
            f"{disease_name} appeared with a {probability:.1f}% probability based on the overall "
            "pattern of your symptoms, age, and health profile combined."
        )

    why_disease = " ".join(why_parts)

    # ── 2. WHY IT OCCURRED ───────────────────────────────────────────────────
    causes = knowledge.get("causes", [
        f"{disease_name} can develop through a combination of infectious, genetic, or environmental factors.",
        "The exact cause varies by individual; consult a doctor for a personalised assessment.",
    ])

    occurred_parts = list(causes[:2])  # Take first 2 general cause sentences

    # Personalise with patient's specific risk factors
    risk_factors = knowledge.get("risk_factors", {})
    personalised = []
    if preexisting:
        for cond in preexisting:
            if cond in risk_factors:
                personalised.append(risk_factors[cond])
    if bp in ("Elevated", "High") and "Hypertension" in risk_factors:
        personalised.append(risk_factors["Hypertension"])
    if cholesterol in ("Elevated", "High") and "high cholesterol" in disease_name.lower():
        personalised.append("Elevated cholesterol is a direct contributing factor.")

    if personalised:
        occurred_parts.append("In your specific case: " + " ".join(personalised[:2]))

    why_occurred = " ".join(occurred_parts)

    # ── 3. HOW TO PREVENT ────────────────────────────────────────────────────
    prevention_list = knowledge.get("prevention", [
        "Follow up with a qualified healthcare professional for personalised prevention advice.",
        "Maintain a healthy lifestyle: balanced diet, regular exercise, and adequate sleep.",
        "Monitor and manage any underlying conditions such as diabetes or hypertension.",
        "Stay current with recommended vaccinations and health screenings.",
    ])

    # ── 4. KEY DRIVERS ───────────────────────────────────────────────────────
    # Sort matched symptoms by their disease probability weight
    sym_weights = {s: disease["symptoms"].get(s, 0) for s in matched_symptoms}
    top_syms = sorted(sym_weights.keys(), key=lambda k: sym_weights[k], reverse=True)[:3]
    key_drivers = [s.replace("_", " ").title() for s in top_syms]

    if bp not in ("Unknown", "Normal") and bp_val > 1.0:
        key_drivers.append(f"{bp} Blood Pressure")
    if active_pre:
        key_drivers.append(active_pre[0])

    key_drivers = key_drivers[:5]  # cap at 5

    return {
        "why_disease": why_disease,
        "why_occurred": why_occurred,
        "how_to_prevent": prevention_list,
        "key_drivers": key_drivers,
    }
